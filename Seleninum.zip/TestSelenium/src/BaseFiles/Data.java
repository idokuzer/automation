package BaseFiles;

import BaseFiles.TestBase;

public class Data {

    private static String downloadsPathOnPc="";
    private static String homePathOnPc="";

    public static String driverPath= System.getProperty("user.dir")+"/Drivers/";
    
    public static String configFilePath= System.getProperty("user.dir")+"/Files/";
    public static String filesPath=System.getProperty("user.dir")+"/Files";
    public static String jsonFilesPath= System.getProperty("user.dir")+"/src/jsonFiles/";
    public static String pomXMLPath=System.getProperty("user.dir")+"/pom.xml";
    

    public static String getDownloadsPathOnPc() {
        setDownloadsPathOnPc();
        return downloadsPathOnPc;
    }

    public static void setDownloadsPathOnPc() {
        String downloadsPathOnPc="";

//        if (TestBase.REMOTE.equalsIgnoreCase("true") && OsCheck.getOperatingSystemType().equals("Linux")){
//            downloadsPathOnPc="/home/seluser/Downloads/";
//        }else{
//            downloadsPathOnPc=System.getProperty("user.home")+"/Downloads/";
//        }
        Data.downloadsPathOnPc = downloadsPathOnPc;
    }

    public static String getHomePathOnPc() {
        setHomePathOnPc();
        return homePathOnPc;
    }

    public static void setHomePathOnPc() {
        String homePathOnPc="";
//        if (TestBase.REMOTE.equalsIgnoreCase("true") && OsCheck.getOperatingSystemType().equals("Linux")){
//            homePathOnPc="/home/seluser";
//        }else{
//            homePathOnPc=System.getProperty("user.home");
//        }
        Data.homePathOnPc = homePathOnPc;
    }
}
