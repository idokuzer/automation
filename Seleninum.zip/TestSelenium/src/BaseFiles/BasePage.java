package BaseFiles;


import BaseFiles.DriverManager;
import BaseFiles.TestBase;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
 

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver.Navigation;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.*;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;

import static BaseFiles.DriverManager.getDriver;
 


public class BasePage {

	 public static ArrayList<String> windowList;
	    private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	    private  static final String NUMERIC_STRING="1234567890";
	    private  static final SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd'T'HH-mm-ss");


	    public WebDriver driver= DriverManager.getDriver();

//	    public BasePage(){
//	    	driver= DriverManager.getDriver();
//	    }

	   


	    public WebElement waitUntilVisibleByLocator(By locator) {
	        WebElement element = null;

	        try {
	            Wait<WebDriver> wait = (new FluentWait(this.driver)).withTimeout(Duration.ofSeconds(80L)).pollingEvery(Duration.ofSeconds(1L)).ignoring(NoSuchElementException.class);
	            element = (WebElement)wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	        } catch (Exception e) {
	          
	        }

	        return element;
	    }
	    
	    public boolean waitUntilVisibleByLocatorWithoutError(By locator) {
	        WebElement element = null;

	        try {
	            Wait<WebDriver> wait = (new FluentWait(this.driver)).withTimeout(Duration.ofSeconds(80L)).pollingEvery(Duration.ofSeconds(1L)).ignoring(NoSuchElementException.class);
	            element = (WebElement)wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	        } catch (Exception e) {
	            return false;
	        }

	        return true;
	    }


	    public WebElement waitUntilClickableByListOfElement(WebElement WebElement) {
	        WebElement element = null;

	        try {
	            Wait<WebDriver> wait = (new FluentWait(this.driver)).withTimeout(Duration.ofSeconds(80L)).pollingEvery(Duration.ofSeconds(1L)).ignoring(NoSuchElementException.class);
	            element = (WebElement)wait.until(ExpectedConditions.elementToBeClickable(WebElement));
	        } catch (Exception e) {
	          //_Fail(e.getMessage());
	        }

	        return element;
	    }


	    public WebElement waitUntilPresenceOfElement(By locator) {
	        WebElement element = null;

	        try {
	            Wait<WebDriver> wait = (new FluentWait(this.driver)).withTimeout(Duration.ofSeconds(80L)).pollingEvery(Duration.ofMillis(1L)).ignoring(StaleElementReferenceException.class).ignoring(NoSuchElementException.class);
	            element = (WebElement)wait.until(ExpectedConditions.presenceOfElementLocated(locator));
	        } catch (Exception e) {

	           //_Fail(e.getMessage());
	        }

	        return element;
	    }

	    public boolean checkElementIsExist(By locator){
	        try {
	            WebElement element= (WebElement) driver.findElement(locator);

	            if (element.isDisplayed() || element.isEnabled()){
	                return true;
	            }else {
	                return false;
	            }

	        }catch (Exception e){

	            return false;
	        }
	    }

	    public boolean checkElementIsExist(WebElement element){
	        try {
	            if (element.isDisplayed() || element.isEnabled()){
	                return true;
	            }else {
	                return false;
	            }

	        }catch (Exception e){
	            return false;
	        }
	    }

	    public boolean checkElementIsExist(By locator,By locator2){

	        try {

	            WebElement element= (WebElement) driver.findElement(locator);
	            element=element.findElement(locator2);

	            if (element.isDisplayed() || element.isEnabled()){
	                return true;
	            }else {
	                return false;
	            }

	        }catch (Exception e){

	            return false;
	        }
	    }

	    public boolean checkElementIsExist(WebElement element,By locator){
	        try {
	            WebElement element1=element.findElement(locator);
	            if (element1.isDisplayed() || element1.isEnabled()){
	                return true;
	            }else {
	                return false;
	            }
	        }catch (Exception e){
	            return false;
	        }
	    }

	    public void checkPageIsReady() {	        
	        
	        try {
	        	
	        	JavascriptExecutor js = (JavascriptExecutor)driver;

		        if (js.executeScript("return document.readyState").toString().equals("complete")){
		           //_Info("Page Is loaded.");
		            return;
		        }

		        for (int i=0; i<25; i++){
		            try {
		                Thread.sleep(1000);
		            }catch (InterruptedException e) {}
		            //To check page ready state.
		            if (js.executeScript("return document.readyState").toString().equals("complete")){
		                break;
		            }
		        }
				
			} catch (Exception e) {
				// TODO: handle exception
			}
	    }


	    public void clickElement(By locator) {
	        WebElement element = this.waitUntilVisibleByLocator(locator);
	        this.clickElement(element);
	    }
	    
	    public void clickElementWithoutWait(By locator) {
	    	try {
	    		driver.findElement(locator).click();
				
			} catch (Exception e) {
				//Fail(e.getMessage());
			}	        
	    }
	    
	    public void clickElementWithoutVisibleControl(By locator) {
	    	try {
	    		WebElement element = (WebElement) driver.findElement(locator);
		        element.click();
				
			} catch (Exception e) {
				//Fail(e.getMessage());
			}
	        
	    }


	    public void clickElement(WebElement element) {
	        this.waitUntilClickableByListOfElement(element).click();
	    }

	    public String getDataInListViaAttribute(By locator,String attributeName,int index){

	        List<WebElement> elements=null;
	        String data=null;
	        try {

	            elements= driver.findElements(locator);
	            data=elements.get(index).getAttribute(attributeName);

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	        return data;
	    }

	    public String getDataViaAttribute(WebElement element,String attributeName){
	        try {
	            return  element.getAttribute(attributeName);
	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	        return null;
	    }

	    public void sendKeysToElement(By locator, String text) {
	        WebElement element = this.waitUntilVisibleByLocator(locator);
	        element = this.waitUntilPresenceOfElement(locator);
	        element.clear();
	        element.sendKeys(new CharSequence[]{text});
	    }
	    
	    public void sendKeysToElementWithSpelling(By locator, String text) {
	       try {
	    	   WebElement element = this.waitUntilVisibleByLocator(locator);
		        element = this.waitUntilPresenceOfElement(locator);
		        element.clear();
		        
		        char[] array=text.toCharArray();
		        
		        for (int i = 0; i < array.length; i++) {
					if (i==1 || i==2 || i==3) {
						Thread.sleep(3000);						
					} else {
						Thread.sleep(500);
					}
					element.sendKeys(String.valueOf(array[i]));
				}          	    
			
		} catch (Exception e) {
			//Fail(e.getMessage());
		}
	    }
	    
	    public void sendKeysToElementWithoutClear(By locator, String text) {
	        WebElement element = this.waitUntilVisibleByLocator(locator);
	        element = this.waitUntilPresenceOfElement(locator);	    
	        element.sendKeys(text);
	    }	  

	    public void sendKeysToElement(By locator, Keys keys) {
	        WebElement element = this.waitUntilVisibleByLocator(locator);
	        element = this.waitUntilPresenceOfElement(locator);
	        element.sendKeys(keys);
	    }


	    public void sendKeysToElement(WebElement element, String text) {
	        element.clear();
	        element.sendKeys(new CharSequence[]{text});
	    }

	    public void sendKeysToElementViaJS(By locator,String text){
	        try {
	            JavascriptExecutor js = (JavascriptExecutor)driver;
	            WebElement elem = (WebElement) driver.findElement(locator);
	            js.executeScript("arguments[0].value =`"+text+"`", elem);
	        }catch (Exception e){
	            e.getStackTrace();
	        }
	    }

	    public void sendKeysToElementWithoutClean(By locator, String text) {
	        WebElement element = this.waitUntilVisibleByLocator(locator);
	        element = this.waitUntilPresenceOfElement(locator);
	        element.sendKeys(new CharSequence[]{text});
	    }
	    
	    public void sendKeysToElementViaAction(By locator,String key){

	        try {
	            Actions builder = new Actions(driver);
	            WebElement element = (WebElement) driver.findElement(locator);
	            builder.sendKeys(key).build().perform();

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	    }
	    
	
	    public int getSizeOfList(By locator){
	        try {
	        	waitUntilVisibleByLocator(locator);
	            List<WebElement> list= driver.findElements(locator);
	            return list.size();

	        }catch (Exception e){
	            return 0;
	        }
	    }
	    
	    public int getSizeOfListWithoutVisibleControl(By locator){
	        try {	        	
	            List<WebElement> list= driver.findElements(locator);
	            return list.size();

	        }catch (Exception e){
	            return 0;
	        }
	    }

	    public int getSizeOfListForVisible(By locator){
	        try {
	            List<WebElement> list= driver.findElements(locator);
	            int count=0;
	            for (int i = 0; i <list.size() ; i++) {
	                WebElement element=list.get(i);
	                if (element.isDisplayed()){
	                    ++count;
	                }
	            }
	            return count;

	        }catch (Exception e){
	            return 0;
	        }
	    }

	    public void clickElementInList(By locator,int index){

	        try {

	            List<WebElement> list= driver.findElements(locator);
	            clickElement(list.get(index));

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	    }

	    public boolean clickElementInListViaAttributeAndData(By locator,String attributeName,String data){

	        boolean elementExist=false;
	        try {

	            List<WebElement> list= driver.findElements(locator);
	            for (int i = 0; i <list.size() ; i++) {
	                String getData=list.get(i).getAttribute(attributeName);
	                if (getData.equals(data)){
	                    elementExist=true;
	                    list.get(i).click();
	                    return true;
	                }
	            }

	            if (!elementExist){
	               //_Fail(data+ " is not detected on the page!");
	            }

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	        return false;
	    }


	    public boolean waitElementWithThreadSleep(By locator, int second){

	        boolean elementExist=false;
	        try {
	            elementExist= checkElementIsExist(locator);

	            if (!elementExist){

	                for (int i = 0; i < 2*second; i++) {
	                    Thread.sleep(500);
	                    elementExist=checkElementIsExist(locator);
	                    if (elementExist){
	                        elementExist=true;
	                        break;
	                    }
	                }
	            }

	            Thread.sleep(1000);
	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }

	        return elementExist;
	    }

	    public boolean waitElementWithThreadSleepViaItem(By locator, int second){

	        int item=0;
	        boolean elementExist=false;
	        try {
	            item=getSizeOfList(locator);

	            if (item==0){

	                for (int i = 0; i < second; i++) {
	                    Thread.sleep(1000);
	                    item=getSizeOfList(locator);
	                    if (item!=0){
	                        elementExist=true;
	                        break;
	                    }
	                }
	            }else{
	                elementExist=true;
	            }
	            Thread.sleep(1000);
	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }

	        return elementExist;
	    }

	    public String getData(By locator){

	        try {
	            WebElement element= (WebElement) driver.findElement(locator);
	            return element.getText();
	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	        return "";
	    }

	    public String getData(By locator, String path){

	        try {
	            WebElement element= (WebElement) driver.findElement(locator);
	            return element.findElement(By.xpath(path)).getText();
	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	        return "";
	    }


	    public void mouseHover(By locator){

	        try {
	            Actions builder = new Actions(driver);
	            WebElement element = (WebElement) driver.findElement(locator);
	            builder.moveToElement(element).build().perform();

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	    }

	    public void mouseHover(WebElement element){

	        try {

	            Actions builder = new Actions(driver);
	            builder.moveToElement(element).build().perform();

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	    }


	    public void clickWebElement(By locator) {
	        WebElement element = this.waitUntilVisibleByLocator(locator);
	        this.clickWebElement(element);
	    }

	    public void clickWebElement(WebElement element) {
	        this.waitUntilClickableByListOfElement(element).click();
	    }


	    public List<WebElement> getWebElementsViaAttribute(By locator){

	        List<WebElement> elements=null;

	        try {

	            elements= driver.findElements(locator);

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }

	        return elements;
	    }

	    public ArrayList getAllDataInList(By locator){

	        ArrayList<String> list=new ArrayList();
	        try {

	            List<WebElement> elementList= driver.findElements(locator);

	            for (int i = 0; i <elementList.size() ; i++) {

	                String data=elementList.get(i).getText();

	                list.add(data);
	            }

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }

	        return list;

	    }

	    public String getAllDataInListViaString(By locator){

	        String list="";
	        try {

	            List<WebElement> elementList= driver.findElements(locator);

	            for (int i = 0; i <elementList.size() ; i++) {

	                String data=elementList.get(i).getText();
	               if (i==(elementList.size()-1)){
	                   list+=data;
	               }else{
	                   list+=data+", ";
	               }
	            }

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }

	        return list;

	    }

	    public void clickElementInListViaContainsMethod(ArrayList<WebElement> list,String data){

	        try {

	            for (int i = 0; i <list.size() ; i++) {

	                if (list.get(i).toString().toLowerCase().contains(data.toLowerCase())){
	                    clickWebElement(list.get(i));
	                    break;
	                }

	                if (i==list.size()-1){
	                   //_Fail("Aranan veri bulunamadi! Aranan Veri:"+data);
	                }
	            }

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	    }


	    public synchronized void getLatestWindow() {
	        windowList = new ArrayList<String>();
	        Set<String> handles = driver.getWindowHandles();

	       //_Info("Parent Handle: " + handles);

	        for (String s : handles) {
	           //_Info(s);
	            windowList.add(windowList.size(), s);
	        }
	        getDriver().switchTo().window(windowList.get(windowList.size() - 1));
	    }

	    public int getWindowsSize() {
	        Set<String> handles = getDriver().getWindowHandles();
	        return handles.size();
	    }

	    public String getCurrentUrl(){

	        try {
	            return driver.getCurrentUrl();
	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	        return null;
	    }


	    public void changeURL(String url){

	        try {

	            driver.get(url);
	            driver.manage().timeouts().pageLoadTimeout(120,TimeUnit.SECONDS);
	            checkPageIsReady();
	            getLatestWindow();

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	    }

	    public String getDataViaJS(WebElement element){

	        try {

	            JavascriptExecutor js = (JavascriptExecutor) driver;

	            return js.executeScript("return arguments[0].value", element).toString();

	        }catch (Exception e){
	          //_Fail(e.getMessage());
	        }

	        return null;
	    }

	    public String randomAlphaNumeric(int count) {

	        StringBuilder builder = new StringBuilder();
	        while (count-- != 0) {
	            int character = (int)(Math.random()*ALPHA_NUMERIC_STRING.length());
	            builder.append(ALPHA_NUMERIC_STRING.charAt(character));
	        }
	        return (builder.toString()).toLowerCase();
	    }

	    public String createNumaricalNumber(int count) {

	        StringBuilder builder = new StringBuilder();
	        while (count-- != 0) {
	            int character = (int)(Math.random()*NUMERIC_STRING.length());
	            builder.append(NUMERIC_STRING.charAt(character));
	        }
	        return builder.toString();
	    }

	    public int createRandomNumber(int maxNumber){
	        try {
	            Random random= new Random();
	            return random.nextInt(maxNumber)+1;
	        }catch (Exception e){
	            return 0;
	        }
	    }

	    public void switchiFrame(By locator){
	        try {
	        	driver.switchTo().frame(driver.findElement(locator));
			} catch (Exception e) {
				//Fail(e.getMessage());
			}
	    }

	    public void moveToElement(By locator){
	        try {
	            Actions actions= new Actions(driver);
	            actions.moveToElement(driver.findElement(locator)).build().perform();
	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	    }

	    public void loadAFile(By moveElementLocatar,By clickElementLocator,String filePath){

	        try {
	            // move to mouse on element
	            moveToElement(moveElementLocatar);
	            // send file path into element
	            driver.findElement(clickElementLocator).sendKeys(filePath);
	            Thread.sleep(2000);
	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	    }

	    public static int getNumbersInString(String data){
	        try {
	            return Integer.parseInt(data.replaceAll("\\D+",""));
	        }catch (Exception e){
	            return 0;
	        }
	    }

	    public String getNumbersInStringReturnString(String data){
	        try {
	            return data.replaceAll("\\D+","");
	        }catch (Exception e){
	            return "";
	        }

	    }

	    public String getDate(String dateFormat){
	        DateFormat sdf = new SimpleDateFormat(dateFormat);
	        Date date = new Date();
	        return sdf.format(date);
	    }

	    public String getDateForPreviousMonth(String dateFormat,int howMuchMonthAgo){
	        DateFormat sdf = new SimpleDateFormat(dateFormat);
	        Date date = Date.from(ZonedDateTime.now().minusMonths(howMuchMonthAgo).toInstant());
	        return sdf.format(date);
	    }

	    public WebElement getWebElementInList(By locator,int index){
	        WebElement element=null;
	        try {
	        	waitUntilVisibleByLocator(locator);
	            List<WebElement> list=driver.findElements(locator);
	            return list.get(index);

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	        return element;
	    }

	    public WebElement getWebElementInList(WebElement element,By locator){
	        WebElement element1=null;
	        try {
	            element1=element.findElement(locator);
	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	        return element1;
	    }

	    public WebElement getWebElementInList(By locator,String attribute,String data){
	        WebElement element=null;
	        try {
	            List<WebElement> list=driver.findElements(locator);
	            for (int i = 0; i <list.size() ; i++) {
	                String getData=list.get(i).getAttribute(attribute);
	                if (getData.equals(data)){
	                    element=list.get(i);
	                }
	            }

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	        return element;
	    }

	    public void cleanInsideOfTextbox(By locator){
	        try {
//	            WebElement element=driver.findElement(locator);
//	            JavascriptExecutor js = (JavascriptExecutor)driver;
//	            js.executeScript("arguments[0].value = '';", element);
	            sendKeysToElement(locator," ");
	            sendKeysToElement(locator,Keys.BACK_SPACE);
	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	    }

	    public static boolean linkExists(String URLName){
	        try {
	            HttpURLConnection.setFollowRedirects(false);
	            HttpURLConnection con = (HttpURLConnection) new URL(URLName).openConnection();
	            con.setRequestMethod("HEAD");
	            return (con.getResponseCode() == HttpURLConnection.HTTP_OK);
	        }
	        catch (Exception e) {
	          //_Fail(e.getMessage());
	            return false;
	        }
	    }

	    public void closeCurrentWindow(){
	        ((JavascriptExecutor) driver)
	                .executeScript("window.close();");
	    }

	    public boolean checkElementEnable(By locator){
	    	boolean elementExist=false;
	    	try {
				elementExist=driver.findElement(locator).isEnabled();
			} catch (Exception e) {
				return false;
			}
	        return elementExist;
	    }
	    
	    public boolean checkElementDisplayed(By locator){
	    	boolean elementExist=false;
	    	try {
				elementExist=driver.findElement(locator).isDisplayed();
			} catch (Exception e) {
				return false;
			}
	        return elementExist;
	    }

	    public boolean checkElementEnableInList(By locator,int index){
	        List<WebElement> list=driver.findElements(locator);
	        return list.get(index).isEnabled();
	    }

	    public void refreshURL(){

	        try {

	            driver.navigate().refresh();
	            driver.manage().timeouts().pageLoadTimeout(120,TimeUnit.SECONDS);
	            checkPageIsReady();
	            getLatestWindow();

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	    }

	    public static boolean deleteFile(String path,String fileName){
	        try {
	            File tempFile = new File(path+fileName);
	            boolean exists = tempFile.exists();
	            if (exists){
	                tempFile.delete();
	            }

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	        return true;
	    }

	    public static void deleteDirectoryRecursion(String folderPath) {
	      try {
	          File file=new File(folderPath);
	          if (file.isDirectory()) {
	              File[] entries = file.listFiles();
	              if (entries != null) {
	                  for (File entry : entries) {
	                      String path=entry.getPath();
	                      deleteDirectoryRecursion(path);
	                  }
	              }
	          }
	          if (!file.delete()) {
	              throw new IOException("Failed to delete " + file);
	          }

	      }catch (Exception e){
	          e.getStackTrace();
	      }
	    }

	    public static boolean checkFileExist(String path,String fileName){
	        try {
	            File tempFile = new File(path+fileName);
	            return tempFile.exists();
	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	        return false;
	    }

	    public void openNewWindow(){
	        try {
	            ((JavascriptExecutor)driver).executeScript("window.open()");
	            ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
	            driver.switchTo().window(tabs.get(1));
	            Thread.sleep(1000);
	        }catch (Exception e){
	            e.getStackTrace();
	        }
	    }


	    public boolean elementIsSelected(By locator){
	        try {
	            return driver.findElement(locator).isSelected();
	        }catch (Exception e){
	        //_Fail(e.getMessage());
	        }
	        return false;
	    }

	    public String getDataInList(By locator,int index){

	        List<WebElement> elements=null;
	        String data=null;
	        try {

	            elements= driver.findElements(locator);
	            data=elements.get(index).getText();

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	        return data;
	    }

	    public String convertArrayToString(String[] array){
	        String data="";
	        for (int i = 0; i <array.length ; i++) {
	            if (i==(array.length-1)){
	                data+=array[i];
	            }else {
	                data+=array[i]+", ";
	            }
	        }
	        return data;
	    }

	    public String convertArrayListToString(ArrayList list){
	        String data="";
	        for (int i = 0; i <list.size() ; i++) {
	            if (i==(list.size()-1)){
	                data+=list.get(i);
	            }else {
	                data+=list.get(i)+", ";
	            }
	        }
	        return data;
	    }

	    public boolean checkElementEnableViaAttribute(By locator,String attribute){
	        String getData=getWebElementInList(locator,0).getAttribute(attribute);
	        return !getData.contains("disabled");
	    }

	    public static File[] findAllFiles(String path,String fileName){
	        File[] files =null;
	        try {
	            File dir = new File(path+".");
	            FileFilter fileFilter = new WildcardFileFilter(fileName);
	            files = dir.listFiles(fileFilter);
	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	        return files;
	    }

	    public static boolean deleteAllFiles(String path,String fileName){
	        try {
	            File[] fileNames=findAllFiles(path,fileName);

	            for (int i = 0; i <fileNames.length ; i++) {
	               fileNames[i].delete();
	            }
	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }        
	        return false;
	    }

	    public static String  getFileName(String path,String regularExpression){
	        String fileName="";
	        try {
	            File[] fileNames=findAllFiles(path,regularExpression);
	            if (fileName.length()==0){
	                for (int i = 0; i <6 ; i++) {
	                    Thread.sleep(1000);
	                    fileNames=findAllFiles(path,regularExpression);
	                    if (fileName.length()!=0){
	                        break;
	                    }
	                }
	            }
	            fileName= fileNames[0].getName();
	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	        return fileName;
	    }

	    public boolean clickElementInListViaData(By locator,String data){

	        boolean elementExist=false;
	        try {

	            List<WebElement> list= driver.findElements(locator);
	            for (int i = 0; i <list.size() ; i++) {
	                String getData=list.get(i).getText();
	                if (getData.equals(data)){
	                    elementExist=true;
	                    list.get(i).click();
	                    return true;
	                }
	            }

	            if (!elementExist){
	               //_Fail(data+ " is not detected on the page!");
	            }

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	        return false;
	    }

	    public static String getDataInStringViaRegex(String data,String regex){
	       String getData="";
	        Matcher matcher = Pattern.compile(regex).matcher(data);
	        while(matcher.find()) {
	            getData=matcher.group();
	        }
	       return getData;
	    }





	    
	    
	    

 
    public void back() {
    	try {
    		driver.navigate().back();
			
		} catch (Exception e) {
			//Fail(e.getMessage());
		}
    }
    
    
    public static boolean checkJenkinsParamatersExist() {
    	try {
    		if (System.getenv("PLATFORMNAME").isEmpty() || System.getenv("PLATFORMNAME")==null){
    			return false;
    		}else {
    			return true;
    		}
			
		} catch (Exception e) {
			return false;
		}    
    }
    
    

	public static File webTakeScreenshot()
			throws IOException {
		File srcFile = ((TakesScreenshot) DriverManager.getDriver())
				.getScreenshotAs(OutputType.FILE);		
		String filename = UUID.randomUUID().toString();
		File targetFile = new File(System.getProperty("user.dir")
				+ "/test-output/cucumber-reports/screenshots/" + filename
				+ ".png");
		FileUtils.copyFile(srcFile, targetFile);
		return targetFile;
	}
    
   
	   public void clickElementViaJS(By locator) {
	       try {
	           WebElement element=driver.findElement(locator);
	           JavascriptExecutor executor = (JavascriptExecutor) driver;
	           executor.executeScript("arguments[0].click();", element);
	       }catch (Exception e){
	           Assert.fail(e.getMessage());
	       }
	    }
	   
	   public void clickElementViaAction(By locator){

	        try {
	            Actions builder = new Actions(driver);
	            WebElement element = (WebElement) driver.findElement(locator);
	            builder.click(element).build().perform();

	        }catch (Exception e){
	           //_Fail(e.getMessage());
	        }
	    }
	   
	   
	   public void navigateBack(int times){

	        try {

	            for (int i = 0; i <times ; i++) {
	                driver.navigate().back();
	                driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
	                checkPageIsReady();
	                Thread.sleep(1000);
	            }

	            getLatestWindow();

	        }catch (Exception e){
	            Assert.fail(e.getMessage());
	        }

	    }
	   
	   
    public void scrollToBottom() {
	    	
	    	try {
	    		
			int x = driver.manage().window().getSize().width / 2;				  
			int start_y = (int) (driver.manage().window().getSize().height * 0.8);				  
			int end_y = (int) (driver.manage().window().getSize().height * 0.2);
				  
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,"+(start_y-end_y)+")", "");
					
			} catch (Exception e) {
				//Fail(e.getMessage());
			}
	    
	      }
    
    
    public void scrollToBottom(double end_y,double start_y) {
    	
    	try {   		
			  
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,"+(start_y-end_y)+")", "");
				
		} catch (Exception e) {
			//Fail(e.getMessage());
		}
    
      }
    
  public void scrollToUp() {
    	
    	try {
    		
    		int x = driver.manage().window().getSize().width / 2;				  
			int start_y = (int) (driver.manage().window().getSize().height * 0.8);				  
			int end_y = (int) (driver.manage().window().getSize().height * 0.2);
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,"+(end_y-start_y)+")", "");
    		  
						
		} catch (Exception e) {
			//Fail(e.getMessage());
		}
    
      }
    
    
    public void scrollToButtonTillElementDisplayed(By locator) {
    	try {
    		
    		WebElement element = driver.findElement(locator);
    		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
    		Thread.sleep(1000); 
			
		} catch (Exception e) {
			//Fail(e.getMessage());
		}
    }

public void setAttribute(String findBy,String idOrClassValue,int index,String attributeName, String value) {
    	
    	try {  
    		JavascriptExecutor js = (JavascriptExecutor) driver;
    
    		if (findBy.equalsIgnoreCase("id")) {    			
    			js.executeScript("document.getElementById('"+idOrClassValue+"').setAttribute('"+attributeName+"', '"+value+"')");				
			} else if(findBy.equalsIgnoreCase("class")) {
				js.executeScript("document.getElementsByClassName('"+idOrClassValue+"')["+index+"].setAttribute('"+attributeName+"', '"+value+"')");

			}else {
				//Fail("Lutfen locator icin id ya da class bilgisi ile bu metodu calistiriniz!!!");
			}    		
    					
		} catch (Exception e) {
			//Fail(e.getMessage());
		}
    	
    }

private static LocalDate findNextDays(LocalDate localdate,int day)
{
  return localdate.plusDays(day);
}
 
private static LocalDate findPrevDays(LocalDate localdate,int day)
{
  return localdate.minusDays(day);
}

public String getNextOrPrevDate(boolean nextDays,int day,String dateFormat) {
	String data="";
	try {
		
		LocalDate todayDate = LocalDate.now();
		LocalDate date=null;
		if (nextDays) {
			date=findNextDays(todayDate,day);
		} else {
			date=findPrevDays(todayDate,day);
		}
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormat);     
		data= formatter.format(date);	
		
	} catch (Exception e) {
		//Fail("Tarih datasi olusturulurken hata alinmistir. Detay: "+e.getMessage());
	}
	
	return data;
}
      

public static void resize(String inputImagePath, String outputImagePath,
		int scaledWidth, int scaledHeight) throws IOException {
	// reads input image
	File inputFile = new File(inputImagePath);
	BufferedImage inputImage = ImageIO.read(inputFile);

	// creates output image
	BufferedImage outputImage = new BufferedImage(scaledWidth,
			scaledHeight, inputImage.getType());

	// scales the input image to the output image
	Graphics2D g2d = outputImage.createGraphics();
	g2d.drawImage(inputImage, 0, 0, scaledWidth, scaledHeight, null);
	g2d.dispose();

	// extracts extension of output file
	String formatName = outputImagePath.substring(outputImagePath
			.lastIndexOf(".") + 1);

	// writes to output file
	ImageIO.write(outputImage, formatName, new File(outputImagePath));
}

public static void resize(String inputImagePath, String outputImagePath,
		double percent) throws IOException {
	File inputFile = new File(inputImagePath);
	BufferedImage inputImage = ImageIO.read(inputFile);
	int scaledWidth = (int) (inputImage.getWidth() * percent);
	int scaledHeight = (int) (inputImage.getHeight() * percent);
	resize(inputImagePath, outputImagePath, scaledWidth, scaledHeight);
}
      
public File mobileTakeScreenshot(){
	File targetFile=null;
	
	try {
		
		File srcFile = ((TakesScreenshot) driver)
    			.getScreenshotAs(OutputType.FILE);
    	double percent = 1;
    	resize(srcFile.getAbsolutePath(), srcFile.getAbsolutePath(), percent);
    	String filename = UUID.randomUUID().toString();
    	targetFile = new File(System.getProperty("user.dir")
    			+ "\\test-output\\cucumber-reports\\screenshots\\" + filename
    			+ ".png");
    	FileUtils.copyFile(srcFile, targetFile);
		
	} catch (Exception e) {
		//Info("Ekran goruntusu alinirken hata alinmistir! Detay: "+e.getMessage());
	}    	
	
	return targetFile;
}  
    
public void takeScreenshot(Scenario scenario) {
	try {    		
//		 File screenshot = mobileTakeScreenshot();
//         InputStream screenshotStream = new FileInputStream(screenshot);
//         scenario.embed(IOUtils.toByteArray(screenshotStream),
//                 "image/png");		

    scenario.embed(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES), "image/png"); //stick it in the report
   //_Info("Ekran goruntusu alinmistir.");   		
		
	} catch (Exception e) {
		System.out.println("Ekran goruntusu alinirken hata alinmistir! Detay: "+e.getMessage());
	}
}



public String splitDataInElementAndGetAPartOfTheData(By locator,String regx,int index) {
	
	try {		
		String value= getData(locator);
		String[] array=value.split(regx);		
		return array[index];		
	} catch (Exception e) {
		// TODO: handle exception
	//	//Fail(e.getMessage());
	}
	
	return null;
}


public String chooseARandomDataInListExceptSpecifiedData(By locator,String unwantedData) {
	try {
		
		List<WebElement> list= driver.findElements(locator);
		boolean elementClicked=false;
		for (int i = 0; i < list.size(); i++) {
			
			String getData=getDataInList(locator, i);
			if (!getData.equalsIgnoreCase(unwantedData)) {
				clickElementInList(locator, i);
				elementClicked=true;
				return getData;
			}
			
		}
		
		if (!elementClicked) {
			//Fail(locator+" locator was not clicked!");
		}
		
	} catch (Exception e) {
		// TODO: handle exception
		//Fail(e.getMessage());
	}	
	
	return null;
	
}
    


public boolean sendKeysToElementIfTheElementIsExist(By locator,int second,String text) {	
	boolean elementExist=waitElementWithThreadSleep(locator, second);
	if (elementExist) {
		sendKeysToElement(locator, text);
		return true;
	}
	return false;
}
    
    
 


















}
