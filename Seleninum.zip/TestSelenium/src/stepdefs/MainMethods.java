package stepdefs;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import BaseFiles.BasePage;
import BaseFiles.DriverManager;
import BaseFiles.JsonMethods;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
 


public class MainMethods {
	
	/*
	 * ONEMLI NOT : Sabit degiskenler asagidaki gibidir. feature dosyasinda bu degiskenler parametre olarak verilmesi yeterlidir.
	 * 
	 * Bireysel Musteri icin: customerNo, mobilePassword, phoneNumber,yatirimHesabiNo, hesapNoGonderen, eftIbanNo, eftAliciAdi, tckNo 
	 * 
	 * Ticari Musteri icin: customerNo, corporateCustomerNo, corporateUserCode,corporateUserCode2, corporateMobilePassword, corporatePhoneNumber
	 * 
	 * Genel: testID , testSuitID , sessionID
	 * 
	 */		
//    WebDriver driver=null;
//
 	public MainMethods() {
 		
 
 	  	
 	  
 	}

 	@Given("^urle git")
    public void urle_git() {
    	try {
   
    	
    	  	
    	  	Thread.sleep(2000);
    		WebDriver driver=DriverManager.getDriver();
    	   
    		driver.navigate().to("http://www.trendyol.com");
    		
    		Thread.sleep(5000);
    		
			
		} catch (Exception e) {
			 
		}        	    	
    }
    
 
 	
    @And("^\"([^\"]*)\" butonunu en fazla \"([^\"]*)\" sn bekle, var ise tikla")
    public void clickElementIfItExists(String jsonParameterName, String second) {
    	BasePage basePage=new BasePage();
        By locator=JsonMethods.getLocator(jsonParameterName);
        boolean elementExist=basePage.waitElementWithThreadSleep(locator,Integer.valueOf(second));
        if (elementExist){
        	basePage.clickElement(locator);
         
        }
    }
    



}
