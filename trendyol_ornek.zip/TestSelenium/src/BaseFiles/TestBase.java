package BaseFiles;

import java.lang.reflect.Method;
 

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.BeforeMethod;

public class TestBase {
	
	 @BeforeMethod(alwaysRun = true)
	    public void beforeMethod(Method method,ITestResult arg1){     

	        try {
	        	
	        	System.setProperty("webdriver.chrome.driver", "d:///chromedriver.exe");

	        	//Creating an object of ChromeDriver
	        	WebDriver driver = new ChromeDriver();
	        	DriverManager  .setDriver(driver);
	        	 driver= DriverManager.getDriver();
	            //Ana sayfa acilir
	         
	            	

	        }catch (Exception e){
	            e.printStackTrace();
	        }

	    }

}
