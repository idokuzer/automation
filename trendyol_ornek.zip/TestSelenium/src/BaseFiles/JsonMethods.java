package BaseFiles;

 

import java.io.FileReader;

import org.openqa.selenium.By;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

 
 

 

public class JsonMethods {

    private static JsonObject jsonObject=null;

    private static JsonObject getJsonObject() {
        return jsonObject;
    }

    private static JsonObject setJsonObject(String jsonFileName, String parameterName) {
        try {
            JsonParser jsonParser= new JsonParser();
            FileReader fileReader= new FileReader(Data.jsonFilesPath+jsonFileName);
            Object object= jsonParser.parse(fileReader);
            JsonObject jsonObject= (JsonObject) object;

            JsonArray array= (JsonArray) jsonObject.get("testData");
            for (int i = 0; i <array.size() ; i++) {
                JsonObject testData= (JsonObject) array.get(i);
                String key= String.valueOf(testData.get("key"));
                key=key.substring(1);
                key=key.substring(0,key.length() - 1);

                if (key.equalsIgnoreCase(parameterName)){
                     return testData;
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    private static JsonObject getJsonData(String jsonFileNameAndJsonParameterName){
        String jsonFileName=null;
        String jsonParameterName=null;
        try {
            String array[]=jsonFileNameAndJsonParameterName.split("@");
            jsonFileName=array[0]+".json";
            jsonParameterName=array[1];

          return setJsonObject(jsonFileName,jsonParameterName);

      }catch (Exception e){
          e.printStackTrace();
      }
      return null;
    }

    public static By getLocator(String jsonFileNameAndJsonParameterName){
        By locator=null;
        try {
            jsonFileNameAndJsonParameterName=jsonFileNameAndJsonParameterName.trim();
            JsonObject jsonObject=getJsonData(jsonFileNameAndJsonParameterName);
            String[] array={" "," "};

            
            array[0]= String.valueOf(jsonObject.get("webType"));
            array[1]=String.valueOf(jsonObject.get("webValue"));
           

            String data=array[1];
            array[0]= array[0].substring(1);
            array[0]= array[0].substring(0,array[0].length() - 1);
            data=data.substring(1);
            data=data.substring(0,data.length() - 1);

            if(array[0].equalsIgnoreCase("id")){
                locator= By.id(data);
            }else if(array[0].equalsIgnoreCase("className")){
                locator=By.className(data);
            }else if(array[0].equalsIgnoreCase("xpath")){
                locator=By.xpath(data);
            }else if(array[0].equalsIgnoreCase("cssSelector")){
                locator=By.cssSelector(data);
            }else if(array[0].equalsIgnoreCase("linkText")){
                locator=By.linkText(data);
            }else if(array[0].equalsIgnoreCase("partialLinkText")){
                locator=By.partialLinkText(data);
            }

            }catch (Exception e){
            e.printStackTrace();
        }
        return locator;
    }



}
